function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Y2ngtICmso":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

